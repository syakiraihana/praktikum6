<?php
defined('BASEPATH') OR exit('No direct script access allowed');
    class Matakuliah extends CI_Controller {

    public function index(){
        $this->load->model('Matakuliah_model','mk1');

        $this->mk1->id=1;
        $this->mk1->nama='Pemrograman Web 2';
        $this->mk1->sks='3';
        $this->mk1->kode='3001';

        $this->load->model('Matakuliah_model','mk2');  
        
        $this->mk2->id=2;
        $this->mk2->nama='Jaringan Komputer';
        $this->mk2->sks='3';
        $this->mk2->kode='3002';

        $this->load->model('Matakuliah_model','mk3');  
        
        $this->mk3->id=3;
        $this->mk3->nama='Basis Data';
        $this->mk3->sks='4';
        $this->mk3->kode='4001';

        $this->load->model('Matakuliah_model','mk4');  
        
        $this->mk4->id=4;
        $this->mk4->nama='User Interface & User Experience';
        $this->mk4->sks='3';
        $this->mk4->kode='3003';
 
        $list_mk = [$this->mk1, $this->mk2, $this->mk3, $this->mk4];
        $data['list_mk']=$list_mk;
 
        // $this->load->view('header');
        $this->load->view('matakuliah/index',$data);
        // $this->load->view('footer');
 }
}
